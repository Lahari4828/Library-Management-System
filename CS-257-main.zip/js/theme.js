;
(function ($) {
    "use strict"


})(jQuery)